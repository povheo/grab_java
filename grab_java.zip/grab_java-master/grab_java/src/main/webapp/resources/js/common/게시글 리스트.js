
/*window.onload=()=>{
	for(let i = 0; i<)
    const ttt = document.getElementsByClassName("content")[0].innerHTML;
    document.getElementsByClassName("content")[0].innerHTML = ttt.substring(0,66)+'...';
}*/

/*const hits=()=>{
	const xhr = new XMLHttpRequest();
	xhr.open("post","/hitsCount",true);
}*/

/*$(function(){
	
});*/
